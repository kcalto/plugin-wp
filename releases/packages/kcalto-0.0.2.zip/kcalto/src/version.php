<?php define('KCALTO_CURRENT_VERSION', '0.0.2') ?>
